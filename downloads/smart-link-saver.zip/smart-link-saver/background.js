// background.js

// This event is fired when the extension is first installed,
// when the extension is updated to a new version, and when Chrome is updated.
chrome.runtime.onInstalled.addListener(() => {
    console.log("Smart Link Saver extension installed or updated.");
});

// Listen for the command to be triggered
chrome.commands.onCommand.addListener(async (command) => {
    if (command === "_execute_action") {
        // This opens the popup when the user uses the keyboard shortcut.
        chrome.action.openPopup();
    }
});