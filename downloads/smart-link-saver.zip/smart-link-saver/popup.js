document.addEventListener('DOMContentLoaded', async () => {
    const saveButton = document.getElementById('saveButton');
    const pasteSaveButton = document.getElementById('pasteSaveButton'); // Get the new button
    const noteInput = document.getElementById('note');
    const tagsInput = document.getElementById('tags');
    const messageContainer = document.getElementById('message-container');
    const darkModeToggle = document.getElementById('darkModeToggle');
    const versionNumber = document.getElementById('version-number');
    
    // --- Quick Search from Popup ---
    const popupSearchInput = document.getElementById('popup-search-input');
    const searchResultsDiv = document.getElementById('searchResults');
    const mainContentDiv = document.getElementById('main-content');
    
    // Theme management
    function applyTheme(theme) {
        if (theme === 'dark') {
            document.body.classList.add('dark-mode');
            if (darkModeToggle) darkModeToggle.checked = true;
        } else {
            document.body.classList.remove('dark-mode');
            if (darkModeToggle) darkModeToggle.checked = false;
        }
    }

    chrome.storage.local.get('theme', (data) => {
        const savedTheme = data.theme || 'light';
        applyTheme(savedTheme);
    });

    if (darkModeToggle) {
        darkModeToggle.addEventListener('change', function() {
            const newTheme = this.checked ? 'dark' : 'light';
            applyTheme(newTheme);
            chrome.storage.local.set({ theme: newTheme });
        });
    }

    // Version number
    const manifest = chrome.runtime.getManifest();
    versionNumber.textContent = `v${manifest.version}`;

    // Display a message for a few seconds and resize popup
    function showMessage(message, type = 'success') {
        messageContainer.textContent = message;
        messageContainer.className = `show ${type}`;

        setTimeout(() => {
            messageContainer.className = '';
            window.resizeTo(380, 260); 
        }, 3000);
    }

    // --- Centralized save logic for reuse ---
    async function saveLink(urlToSave, note, tags) {
        if (urlToSave && urlToSave.includes('saved-links.html')) {
            showMessage('Cannot save the Saved Links page.', 'error');
            return;
        }

        if (!urlToSave) {
            showMessage('Error: No URL to save.', 'error');
            return;
        }

        if (urlToSave.startsWith('chrome://') || urlToSave.startsWith('about:')) {
            showMessage('Cannot save this type of page.', 'error');
            return;
        }

        const tagsArray = tags.split(',').map(tag => tag.trim()).filter(tag => tag.length > 0);
        const newLink = {
            url: urlToSave,
            note: note,
            tags: tagsArray,
            date: new Date().toISOString()
        };

        chrome.storage.local.get({ savedLinks: [] }, (data) => {
            const savedLinks = data.savedLinks;
            const isDuplicate = savedLinks.some(link => link.url === urlToSave);

            if (isDuplicate) {
                showMessage('This URL has already been saved!', 'error');
                return;
            }

            savedLinks.push(newLink);
            chrome.storage.local.set({ savedLinks: savedLinks }, () => {
                if (chrome.runtime.lastError) {
                    showMessage('Failed to save link.', 'error');
                } else {
                    showMessage('Link saved successfully!');
                    noteInput.value = '';
                    tagsInput.value = '';
                }
            });
        });
    }

    // Get the current tab's info and pre-fill the form
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.url) {
        noteInput.value = tab.title;
    }

    // --- Quick Search from Popup ---
    popupSearchInput.addEventListener('input', async () => {
        const searchTerm = popupSearchInput.value.toLowerCase();
        
        if (searchTerm.length > 0) {
            mainContentDiv.style.display = 'none';
            searchResultsDiv.style.display = 'block';
            window.resizeTo(380, 500);

            const data = await chrome.storage.local.get({ savedLinks: [] });
            const allLinks = data.savedLinks;
            
            const filteredLinks = allLinks.filter(link => {
                const searchString = `${link.note} ${link.url} ${link.tags.join(' ')}`.toLowerCase();
                return searchString.includes(searchTerm);
            });

            renderSearchResults(filteredLinks);
        } else {
            mainContentDiv.style.display = 'block';
            searchResultsDiv.style.display = 'none';
            window.resizeTo(380, 260); 
        }
    });

    function renderSearchResults(links) {
        searchResultsDiv.innerHTML = '';
        if (links.length === 0) {
            searchResultsDiv.innerHTML = `<p style="text-align:center; padding: 10px; color: var(--secondary-text-color);">No matches found.</p>`;
            return;
        }
        
        links.forEach(link => {
            const linkElement = document.createElement('a');
            linkElement.className = 'search-result-item';
            linkElement.href = link.url;
            linkElement.target = '_blank';
            
            const title = document.createElement('div');
            title.className = 'result-title';
            title.textContent = link.note || 'No Note';
            
            const url = document.createElement('div');
            url.className = 'result-url';
            url.textContent = link.url;
            
            linkElement.appendChild(title);
            linkElement.appendChild(url);
            searchResultsDiv.appendChild(linkElement);
        });
    }

    // Save button click
    saveButton.addEventListener('click', async () => {
        const [currentTab] = await chrome.tabs.query({ active: true, currentWindow: true });
        const urlToSave = currentTab.url;
        const note = noteInput.value.trim();
        const tags = tagsInput.value.trim();
        saveLink(urlToSave, note, tags);
    });

    // NEW: Paste & Save button click
    pasteSaveButton.addEventListener('click', async () => {
        try {
            const clipboardText = await navigator.clipboard.readText();
            if (clipboardText && (clipboardText.startsWith("http://") || clipboardText.startsWith("https://"))) {
                saveLink(clipboardText, "Saved from clipboard", "");
            } else {
                showMessage('The clipboard does not contain a valid URL.', 'error');
            }
        } catch (error) {
            console.error("Failed to read clipboard:", error);
            showMessage('Failed to read clipboard. Please try again.', 'error');
        }
    });
});