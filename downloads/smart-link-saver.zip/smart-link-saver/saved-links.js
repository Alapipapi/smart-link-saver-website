document.addEventListener('DOMContentLoaded', function() {
    const linksContainer = document.getElementById('linksContainer');
    const archivedLinksContainer = document.getElementById('archivedLinksContainer');
    const searchInput = document.getElementById('searchInput');
    const exportButton = document.getElementById('exportButton');
    const clearAllButton = document.getElementById('clearAllButton');
    const deleteSelectedButton = document.getElementById('deleteSelectedButton');
    const tagListContainer = document.getElementById('tagList');
    const linkCountDisplay = document.getElementById('linkCount');
    const sortOptions = document.getElementById('sortOptions');

    const savedLinksButton = document.getElementById('savedLinksButton');
    const archivedLinksButton = document.getElementById('archivedLinksButton');
    
    const importLinksFile = document.getElementById('importLinksFile');
    const importButton = document.getElementById('importButton');

    const editModal = document.getElementById('editModal');
    const closeButton = editModal ? editModal.querySelector('.close') : null;
    const editForm = document.getElementById('editForm');
    const editNoteInput = document.getElementById('editNote');
    const editTagsInput = document.getElementById('editTags');
    const editTagsGroup = document.getElementById('editTagsGroup');
    const editUrlInput = document.getElementById('editUrl');
    const cancelEditButton = document.getElementById('cancelEditButton');
    
    const darkModeToggle = document.getElementById('darkModeToggle');

    let allLinks = [];
    let allArchivedLinks = [];
    let currentTagFilter = null;
    let currentView = 'saved';

    const noSearchResultsMessage = document.createElement('div');
    noSearchResultsMessage.className = 'no-search-results';
    noSearchResultsMessage.innerHTML = 'No links found for your search query. <span class="clear-search">Clear search</span> to see all links.';
    noSearchResultsMessage.style.textAlign = 'center';
    noSearchResultsMessage.style.marginTop = '20px';
    noSearchResultsMessage.style.color = 'var(--secondary-text-color)';
    noSearchResultsMessage.style.display = 'none';

    if (noSearchResultsMessage.querySelector('.clear-search')) {
        noSearchResultsMessage.querySelector('.clear-search').addEventListener('click', () => {
            searchInput.value = '';
            filterAndRender();
        });
    }

    // Theme management
    function applyTheme(theme) {
        if (theme === 'dark') {
            document.body.classList.add('dark-mode');
            if (darkModeToggle) darkModeToggle.checked = true;
        } else {
            document.body.classList.remove('dark-mode');
            if (darkModeToggle) darkModeToggle.checked = false;
        }
    }
    
    chrome.storage.local.get('theme', function(data) {
        const savedTheme = data.theme || 'light';
        applyTheme(savedTheme);
    });
    
    if (darkModeToggle) {
        darkModeToggle.addEventListener('change', function() {
            const newTheme = this.checked ? 'dark' : 'light';
            applyTheme(newTheme);
            chrome.storage.local.set({ theme: newTheme });
        });
    }

    function updateLinkCount() {
        if (!linkCountDisplay) return;
        const totalLinks = currentView === 'saved' ? allLinks.length : allArchivedLinks.length;
        const linksToSearch = currentView === 'saved' ? allLinks : allArchivedLinks;
        const filteredLinks = getFilteredLinks(linksToSearch);
        const displayedLinks = filteredLinks.length;
        if (totalLinks === displayedLinks || displayedLinks === 0) {
            linkCountDisplay.textContent = `${totalLinks} Links`;
        } else {
            linkCountDisplay.textContent = `${displayedLinks} of ${totalLinks} Links`;
        }
    }

    function renderTags() {
        if (!tagListContainer) return;
        tagListContainer.innerHTML = '';
        const linksToSearch = currentView === 'saved' ? allLinks : allArchivedLinks;

        if (linksToSearch.length === 0) {
            tagListContainer.innerHTML = '<p class="no-tags" style="font-style: italic;">No tags found.</p>';
            return;
        }

        const allTags = linksToSearch.flatMap(link => link.tags);
        const uniqueTags = [...new Set(allTags.filter(tag => tag && tag.trim().length > 0))].sort();

        if (uniqueTags.length === 0) {
            tagListContainer.innerHTML = '<p class="no-tags" style="font-style: italic;">No tags found.</p>';
            return;
        }

        uniqueTags.forEach(tagText => {
            const tagButton = document.createElement('button');
            tagButton.className = 'tag-btn';
            if (currentTagFilter === tagText) {
                tagButton.classList.add('active');
            }
            tagButton.textContent = tagText;
            tagButton.addEventListener('click', () => {
                if (currentTagFilter === tagText) {
                    currentTagFilter = null;
                } else {
                    currentTagFilter = tagText;
                }
                filterAndRender();
            });
            tagListContainer.appendChild(tagButton);
        });
    }
    
    function sortLinks(links, sortBy) {
        if (!sortBy) return links;

        const [property, order] = sortBy.split('-');

        return links.sort((a, b) => {
            let aValue, bValue;

            if (property === 'date') {
                aValue = new Date(a.date);
                bValue = new Date(b.date);
            } else if (property === 'url') {
                aValue = a.url.toLowerCase();
                bValue = b.url.toLowerCase();
            } else if (property === 'note') {
                aValue = (a.note || '').toLowerCase();
                bValue = (b.note || '').toLowerCase();
            }

            if (aValue < bValue) return order === 'asc' ? -1 : 1;
            if (aValue > bValue) return order === 'asc' ? 1 : -1;
            return 0;
        });
    }

    function renderLinks(links) {
        const container = currentView === 'saved' ? linksContainer : archivedLinksContainer;
        linksContainer.style.display = currentView === 'saved' ? 'flex' : 'none';
        archivedLinksContainer.style.display = currentView === 'archived' ? 'flex' : 'none';

        container.innerHTML = '';
        const isArchiveView = currentView === 'archived';

        const noLinksMessage = container.querySelector('.no-links');
        if (noLinksMessage) noLinksMessage.style.display = 'none';

        if (links.length === 0) {
            if (isArchiveView && allArchivedLinks.length === 0 || !isArchiveView && allLinks.length === 0) {
                container.innerHTML = `<p class="no-links" style="font-style:italic; text-align:center;">${isArchiveView ? 'No links in archive.' : 'No links saved yet.'}</p>`;
            } else {
                const noSearchResultsClone = noSearchResultsMessage.cloneNode(true);
                container.appendChild(noSearchResultsClone);
                noSearchResultsClone.style.display = 'block';
                if (noSearchResultsClone.querySelector('.clear-search')) {
                    noSearchResultsClone.querySelector('.clear-search').addEventListener('click', () => {
                        searchInput.value = '';
                        filterAndRender();
                    });
                }
            }
        } else {
            links.forEach((link, index) => {
                const linkCard = document.createElement('div');
                linkCard.className = 'link-card';
                linkCard.dataset.url = link.url;
                
                const checkbox = document.createElement('input');
                checkbox.type = 'checkbox';
                checkbox.className = 'link-checkbox';
                checkbox.addEventListener('change', toggleBulkDeleteButton);
                linkCard.appendChild(checkbox);
                
                const linkContent = document.createElement('div');
                linkContent.className = 'link-content';

                const title = document.createElement('div');
                title.className = 'link-title';

                const hasNote = link.note && link.note.trim() !== '';

                if (hasNote) {
                    title.textContent = link.note;
                } else {
                    title.textContent = 'No Notes';
                }
                linkContent.appendChild(title);

                const url = document.createElement('div');
                url.className = 'link-url';
                const maxLength = 60;
                
                const truncatedUrl = link.url.length > maxLength ? link.url.substring(0, maxLength) + '...' : link.url;

                const urlLink = document.createElement('a');
                urlLink.href = link.url;
                urlLink.target = '_blank';
                urlLink.rel = 'noopener noreferrer';
                urlLink.textContent = truncatedUrl;
                urlLink.title = link.url;
                url.appendChild(urlLink);

                linkContent.appendChild(url);

                if (link.tags && link.tags.length > 0) {
                    const tagsDiv = document.createElement('div');
                    tagsDiv.className = 'link-tags';
                    link.tags.forEach(tagText => {
                        const tag = document.createElement('span');
                        tag.className = 'tag';
                        tag.textContent = tagText;
                        tagsDiv.appendChild(tag);
                    });
                    linkContent.appendChild(tagsDiv);
                }

                const date = document.createElement('div');
                date.className = 'link-date';
                const formattedDate = new Date(link.date).toLocaleString();
                date.textContent = `Saved on: ${formattedDate}`;
                linkContent.appendChild(date);
                
                const actions = document.createElement('div');
                actions.className = 'link-actions';

                const visitLink = document.createElement('a');
                visitLink.href = link.url;
                visitLink.target = '_blank';
                visitLink.className = 'visit-link';
                visitLink.textContent = 'Visit';
                
                // Append the "Visit" button first
                actions.appendChild(visitLink);
                
                if (!isArchiveView) {
                    const archiveButton = document.createElement('button');
                    archiveButton.className = 'archive-link';
                    archiveButton.textContent = 'Archive';
                    actions.appendChild(archiveButton);
                } else {
                    const unarchiveButton = document.createElement('button');
                    unarchiveButton.className = 'unarchive-link';
                    unarchiveButton.textContent = 'Unarchive';
                    actions.appendChild(unarchiveButton);
                }

                const copyButton = document.createElement('button');
                copyButton.className = 'copy-link';
                copyButton.textContent = 'Copy';
                
                const editButton = document.createElement('button');
                editButton.className = 'edit-link';
                editButton.textContent = 'Edit';
                
                const deleteButton = document.createElement('button');
                deleteButton.className = 'delete-link';
                deleteButton.textContent = 'Delete';

                // Now append the rest of the buttons in the desired order
                actions.appendChild(copyButton);
                actions.appendChild(editButton);
                actions.appendChild(deleteButton);
                
                linkContent.appendChild(actions);
                linkCard.appendChild(linkContent);
                container.appendChild(linkCard);
            });
        }
        updateLinkCount();
    }
    
    function toggleBulkDeleteButton() {
        const checkedBoxes = document.querySelectorAll('.link-checkbox:checked');
        if (deleteSelectedButton) {
            deleteSelectedButton.style.display = checkedBoxes.length > 0 ? 'block' : 'none';
        }
    }

    function bulkDeleteLinks() {
        const checkedBoxes = document.querySelectorAll('.link-checkbox:checked');
        if (checkedBoxes.length === 0) return;
        
        if (confirm(`Are you sure you want to delete ${checkedBoxes.length} selected link(s)?`)) {
            const urlsToDelete = Array.from(checkedBoxes).map(cb => {
                const linkCard = cb.closest('.link-card');
                return linkCard ? linkCard.dataset.url : null;
            }).filter(url => url !== null);
            
            const linksToUpdate = currentView === 'saved' ? allLinks : allArchivedLinks;
            const updatedLinks = linksToUpdate.filter(link => !urlsToDelete.includes(link.url));
            
            const storageKey = currentView === 'saved' ? 'savedLinks' : 'archivedLinks';
            chrome.storage.local.set({ [storageKey]: updatedLinks }, function() {
                if (!chrome.runtime.lastError) {
                    if (currentView === 'saved') allLinks = updatedLinks;
                    else allArchivedLinks = updatedLinks;
                    filterAndRender();
                    if (deleteSelectedButton) {
                        deleteSelectedButton.style.display = 'none';
                    }
                }
            });
        }
    }

    function getFilteredLinks(links) {
        let filtered = [...links];

        const searchTerm = searchInput ? searchInput.value.toLowerCase() : '';
        
        if (searchTerm) {
            if (searchTerm.startsWith('#')) {
                const tagSearchTerm = searchTerm.substring(1).trim();
                filtered = filtered.filter(link => link.tags.some(tag => tag.toLowerCase().includes(tagSearchTerm)));
            } else {
                filtered = filtered.filter(link => {
                    const searchString = `${link.note} ${link.url} ${link.tags.join(' ')}`.toLowerCase();
                    return searchString.includes(searchTerm);
                });
            }
        }
        
        if (currentTagFilter) {
            filtered = filtered.filter(link => link.tags.includes(currentTagFilter));
        }
        
        const sortBy = sortOptions ? sortOptions.value : 'date-desc';
        return sortLinks(filtered, sortBy);
    }

    function filterAndRender() {
        const linksToFilter = currentView === 'saved' ? allLinks : allArchivedLinks;
        const filteredLinks = getFilteredLinks(linksToFilter);
        renderTags();
        renderLinks(filteredLinks);
    }

    function exportLinksAsJSON() {
        const jsonString = JSON.stringify(allLinks, null, 2);
        const blob = new Blob([jsonString], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `smart-link-saver-export-${new Date().toISOString().slice(0, 10)}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }
    
    function importLinksFromJSON(event) {
        const file = event.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = function(e) {
            try {
                const importedLinks = JSON.parse(e.target.result);
                if (!Array.isArray(importedLinks) || !importedLinks.every(link => link.url && link.date)) {
                    alert('Invalid JSON file format. Please import a file previously exported by Smart Link Saver.');
                    return;
                }

                chrome.storage.local.get({ savedLinks: [] }, (data) => {
                    let currentLinks = data.savedLinks;
                    const newLinksToAdd = importedLinks.filter(importedLink => 
                        !currentLinks.some(existingLink => existingLink.url === importedLink.url)
                    );

                    if (newLinksToAdd.length === 0) {
                        alert('No new links to import. All links in the file already exist.');
                        return;
                    }

                    const mergedLinks = [...currentLinks, ...newLinksToAdd];
                    chrome.storage.local.set({ savedLinks: mergedLinks }, () => {
                        alert(`${newLinksToAdd.length} link(s) imported successfully!`);
                        loadLinks();
                    });
                });

            } catch (error) {
                alert('Error parsing JSON file. Please ensure the file is not corrupted.');
            }
        };
        reader.readAsText(file);
    }

    function clearAllLinks() {
        if (confirm("Are you sure you want to delete ALL saved links? This cannot be undone.")) {
            chrome.storage.local.set({ savedLinks: [] }, function() {
                allLinks = [];
                currentTagFilter = null;
                if (searchInput) {
                    searchInput.value = '';
                }
                filterAndRender();
            });
        }
    }
    
    function archiveLink(urlToArchive) {
        const linkIndex = allLinks.findIndex(l => l.url === urlToArchive);
        if (linkIndex > -1) {
            const linkToMove = allLinks.splice(linkIndex, 1)[0];
            allArchivedLinks.push(linkToMove);
            chrome.storage.local.set({ savedLinks: allLinks, archivedLinks: allArchivedLinks }, () => {
                filterAndRender();
            });
        }
    }

    function unarchiveLink(urlToUnarchive) {
        const linkIndex = allArchivedLinks.findIndex(l => l.url === urlToUnarchive);
        if (linkIndex > -1) {
            const linkToMove = allArchivedLinks.splice(linkIndex, 1)[0];
            allLinks.push(linkToMove);
            chrome.storage.local.set({ savedLinks: allLinks, archivedLinks: allArchivedLinks }, () => {
                filterAndRender();
            });
        }
    }

    function openEditModal(originalUrl) {
        const linksToEdit = currentView === 'saved' ? allLinks : allArchivedLinks;
        const linkToEdit = linksToEdit.find(l => l.url === originalUrl);
        if (!linkToEdit) return;
        
        if (editForm && editNoteInput && editTagsInput && editUrlInput) {
            editForm.dataset.originalUrl = originalUrl;
            editNoteInput.value = linkToEdit.note || '';
            editUrlInput.value = linkToEdit.url;
            
            // --- CORRECTED LOGIC: Always show the tags box, and populate it or leave it blank ---
            if (editTagsGroup) {
                editTagsGroup.style.display = 'flex'; // Ensure the tags group is always visible
            }
            editTagsInput.value = linkToEdit.tags.join(', ');
            
            editModal.style.display = 'block';
            setTimeout(() => editModal.classList.add('show'), 10);
        }
    }

    function closeEditModal() {
        if (editModal) {
            editModal.classList.remove('show');
            setTimeout(() => editModal.style.display = 'none', 300);
        }
    }
    
    if (editForm) {
        editForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const originalUrl = editForm.dataset.originalUrl;
            const editedNote = editNoteInput.value.trim();
            const editedTags = editTagsInput.value.split(',').map(tag => tag.trim()).filter(tag => tag.length > 0);
            const editedUrl = editUrlInput.value.trim();
            
            if (originalUrl) {
                const linksToEdit = currentView === 'saved' ? allLinks : allArchivedLinks;
                const linkToUpdate = linksToEdit.find(l => l.url === originalUrl);

                if (linkToUpdate) {
                    linkToUpdate.note = editedNote;
                    linkToUpdate.tags = editedTags;
                    linkToUpdate.url = editedUrl;

                    const storageKey = currentView === 'saved' ? 'savedLinks' : 'archivedLinks';
                    chrome.storage.local.set({ [storageKey]: linksToEdit }, function() {
                        if (!chrome.runtime.lastError) {
                            filterAndRender();
                            closeEditModal();
                        }
                    });
                }
            }
        });
    }

    // Initial data load
    function loadLinks() {
        chrome.storage.local.get({ savedLinks: [], archivedLinks: [] }, function(data) {
            allLinks = data.savedLinks;
            allArchivedLinks = data.archivedLinks;
            filterAndRender();
        });
    }

    // Event listeners
    if (searchInput) {
        searchInput.addEventListener('input', () => {
            currentTagFilter = null;
            filterAndRender();
        });
    }
    if (sortOptions) {
        sortOptions.addEventListener('change', filterAndRender);
    }
    if (exportButton) {
        exportButton.addEventListener('click', exportLinksAsJSON);
    }
    if (clearAllButton) {
        clearAllButton.addEventListener('click', clearAllLinks);
    }
    if (deleteSelectedButton) {
        deleteSelectedButton.addEventListener('click', bulkDeleteLinks);
    }
    if (closeButton) {
        closeButton.addEventListener('click', closeEditModal);
    }
    if (cancelEditButton) {
        cancelEditButton.addEventListener('click', closeEditModal);
    }
    if (editModal) {
        window.addEventListener('click', (event) => {
            if (event.target == editModal) {
                closeEditModal();
            }
        });
    }
    
    savedLinksButton.addEventListener('click', () => {
        currentView = 'saved';
        savedLinksButton.classList.add('active');
        archivedLinksButton.classList.remove('active');
        filterAndRender();
    });

    archivedLinksButton.addEventListener('click', () => {
        currentView = 'archived';
        archivedLinksButton.classList.add('active');
        savedLinksButton.classList.remove('active');
        filterAndRender();
    });

    importButton.addEventListener('click', () => {
        importLinksFile.click();
    });
    importLinksFile.addEventListener('change', importLinksFromJSON);

    // --- NEW: Event Delegation for Link Actions ---
    linksContainer.addEventListener('click', (e) => handleLinkAction(e, allLinks, 'saved'));
    archivedLinksContainer.addEventListener('click', (e) => handleLinkAction(e, allArchivedLinks, 'archived'));

    function handleLinkAction(e, linksArray, view) {
        const target = e.target;
        const linkCard = target.closest('.link-card');
        if (!linkCard) return;

        const url = linkCard.dataset.url;

        if (target.classList.contains('edit-link')) {
            openEditModal(url);
        } else if (target.classList.contains('copy-link')) {
            const link = linksArray.find(l => l.url === url);
            const textToCopy = `Title: ${link.note || link.url}\nURL: ${link.url}\nTags: ${link.tags.join(', ')}`;
            navigator.clipboard.writeText(textToCopy).then(() => {
                alert('Link details copied to clipboard!');
            }).catch(err => {
                console.error('Failed to copy text: ', err);
            });
        } else if (target.classList.contains('delete-link')) {
            if (confirm(`Are you sure you want to delete this link?\n\nThis cannot be undone.`)) {
                if (view === 'saved') {
                    allLinks = allLinks.filter(l => l.url !== url);
                    chrome.storage.local.set({ savedLinks: allLinks }, filterAndRender);
                } else {
                    allArchivedLinks = allArchivedLinks.filter(l => l.url !== url);
                    chrome.storage.local.set({ archivedLinks: allArchivedLinks }, filterAndRender);
                }
            }
        } else if (target.classList.contains('archive-link')) {
            archiveLink(url);
        } else if (target.classList.contains('unarchive-link')) {
            unarchiveLink(url);
        }
    }

    loadLinks();
});